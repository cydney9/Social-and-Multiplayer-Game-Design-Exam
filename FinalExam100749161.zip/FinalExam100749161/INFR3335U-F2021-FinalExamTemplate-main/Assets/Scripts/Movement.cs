//Cydney-Wade Drennan 100749161
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Movement : MonoBehaviour
{
    private Rigidbody rb;
    public Joystick joy;
    public GameObject player; //Attach player object here
    private float movespeed;
 
    private float dirX, dirY, dirZ;


    // Start is called before the first frame update
    void Start()
    {
        movespeed = 3f;
        
        rb = GetComponent<Rigidbody>();
    }

    // Update is called once per frame
    void Update()
    {
        dirX = joy.Horizontal * movespeed;
        dirZ = joy.Vertical * movespeed;
        Vector3 pos = player.transform.position;

        dirY = 0.0f;
    }
    private void FixedUpdate()
    {
        rb.velocity = new Vector3(dirX, dirY, dirZ);
    }
}
