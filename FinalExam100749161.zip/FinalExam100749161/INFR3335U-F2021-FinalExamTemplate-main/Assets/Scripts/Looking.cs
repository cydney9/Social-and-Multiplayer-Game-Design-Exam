//Cydney-Wade Drennan 100749161
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Looking : MonoBehaviour
{

    public Joystick joyLook;
    public GameObject theCamera; //Attach player object here
    private float lookSpeed;

    

    // Start is called before the first frame update
    void Start()
    {
        lookSpeed = 0.01f;

    }

    // Update is called once per frame
    void Update()
    {
        if (joyLook.Horizontal > 0) 
        {
            theCamera.transform.Rotate(0.0f, 90.0f * lookSpeed, 0.0f, Space.Self);
        }
        else if (joyLook.Horizontal < 0)
        {
            theCamera.transform.Rotate(0.0f, -90.0f * lookSpeed, 0.0f, Space.Self);
        }
       


    }
  
}
